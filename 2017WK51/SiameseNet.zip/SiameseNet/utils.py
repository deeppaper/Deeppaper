import matplotlib.pyplot as plt
import os
import numpy as np


def get_language_names():
    train_languages = ['Hebrew', 'Ojibwe_(Canadian_Aboriginal_Syllabics)', 'Japanese_(katakana)', 'Arcadian',
                       'Asomtavruli_(Georgian)', 'Syriac_(Estrangelo)', 'Grantha', 'Tagalog', 'Gujarati', 'Tifinagh',
                       'Latin', 'Bengali', 'Inuktitut_(Canadian_Aboriginal_Syllabics)', 'Alphabet_of_the_Magi',
                       'Early_Aramaic', 'Braille', 'Korean', 'Greek', 'Futurama', 'Japanese_(hiragana)', 'N_Ko',
                       'Blackfoot_(Canadian_Aboriginal_Syllabics)', 'Anglo-Saxon_Futhorc', 'Mkhedruli_(Georgian)',
                       'Sanskrit', 'Malay_(Jawi_-_Arabic)', 'Cyrillic', 'Balinese', 'Burmese_(Myanmar)', 'Armenian']

    test_languages = ['Sylheti', 'Ge_ez', 'Atlantean', 'Gurmukhi', 'Manipuri', 'Syriac_(Serto)', 'Avesta', 'Mongolian',
                     'Kannada', 'Oriya', 'Angelic', 'Old_Church_Slavonic_(Cyrillic)', 'Malayalam', 'Keble', 'Glagolitic',
                     'Tengwar', 'Atemayar_Qelisayer', 'ULOG', 'Aurek-Besh', 'Tibetan']

    return train_languages, test_languages


def read_data(path, role):
    """
    :param path: data path
    :param role: 'train' or 'test'
    :return: datas ==> shape: (alphabets, examples, img_w, img_h, img_ch)
    """
    train_languages, test_languages = get_language_names()

    if role == 'train':
        languages = train_languages
    elif role == 'test':
        languages = test_languages

    datas = []
    for i, language in enumerate(languages):
        language_dir = os.path.join(path, language)

        for alphabet in os.listdir(language_dir):
            alphabet_dir = os.path.join(language_dir, alphabet)
            alphabet_imgs = []

            for filename in os.listdir(alphabet_dir):
                img = plt.imread(os.path.join(alphabet_dir, filename))
                alphabet_imgs.append(img)

            datas.append(alphabet_imgs)

    return np.expand_dims(np.array(datas), axis=4)


def get_batch(train_datas, b_size):
    """
    :param train_datas: read_data 함수에서 얻은 train_data
    :param b_size: batch_size
    :return: batch_size 의 절반은 다른 언어, 절반은 같은 언어로 구성하여
            [이미지1, 이미지2], y
            형태로 batch를 만들어 냄. y는 이미지가 같을 확률 ==> 같으면 1, 아니면 0
    """
    num_cat = train_datas.shape[0]
    num_ex = train_datas.shape[1]

    x_pairs = [np.zeros((b_size, 105, 105, 1)) for i in range(2)]
    y = np.zeros((b_size, ))
    y[b_size // 2:] = 1

    for i in range(b_size):
        category_1 = np.random.randint(0, num_cat)
        idx_1 = np.random.randint(0, num_ex)

        x_pairs[0][i, :, :, :] = train_datas[category_1][idx_1]

        if i >= b_size // 2:
            category_2 = category_1
            idx_2 = (idx_1 + np.random.randint(1, num_ex)) % num_ex
        else:
            category_2 = (category_1 + np.random.randint(1, num_cat)) % num_cat
            idx_2 = np.random.randint(0, num_ex)

        x_pairs[1][i, :, :, :] = train_datas[category_2][idx_2]

    return x_pairs, y


def make_oneshot_task(test_datas, N):
    """
    :param N: N way one shot learning
    :return: [test_image, support_set], y
    """
    num_cat = test_datas.shape[0]
    num_ex = test_datas.shape[1]

    x_pairs = [np.zeros((N, 105, 105, 1)) for i in range(2)]
    y = np.zeros((N, ))
    y[0] = 1

    category_t = np.random.randint(0, num_cat)
    idx_t = np.random.randint(0, num_ex)

    for i in range(N):
        x_pairs[0][i, :, :, :] = test_datas[category_t][idx_t]

        if i == 0:
            idx = (idx_t + np.random.randint(1, num_ex)) % num_ex
            x_pairs[1][i, :, :, :] = test_datas[category_t][idx]
            continue

        category = (category_t + np.random.randint(1, num_cat)) % num_cat
        idx = np.random.randint(0, num_ex)
        x_pairs[1][i, :, :, :] = test_datas[category][idx]

    return x_pairs, y


def test_oneshot(model, test_datas, N, k):
    n_correct = 0
    print("Evaluating model on {} unique {} way one-shot learning tasks ...".format(k, N))
    for i in range(k):
        inputs, targets = make_oneshot_task(test_datas, N)
        probs = model.predict(inputs)
        if np.argmax(probs) == 0:
            n_correct += 1
    percent_correct = (100.0 * n_correct / k)
    print("Got an average of {}% {} way one-shot learning accuracy".format(percent_correct, N))
    return percent_correct
