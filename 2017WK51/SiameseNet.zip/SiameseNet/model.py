from keras.layers import Input, Conv2D, Lambda, Dense, Flatten, MaxPooling2D
from keras.models import Model
from keras.regularizers import l2
from keras import backend as K

import numpy as np


class SiameseNet:
    def __init__(self):
        inp1 = Input((105, 105, 1))
        inp2 = Input((105, 105, 1))

        base_model = self.build_base_model()
        output1 = base_model(inp1)
        output2 = base_model(inp2)

        x = Lambda(lambda x: K.abs(x[0] - x[1]))([output1, output2])
        prediction = self.my_dense(1, x)
        self.siamese_net = Model(inputs=[inp1, inp2], outputs=prediction)

    def cw_init(self, shape):
        values = np.random.normal(loc=0, scale=1e-2, size=shape)
        return K.variable(values)

    def cb_init(self, shape):
        values = np.random.normal(loc=0.5, scale=1e-2, size=shape)
        return K.variable(values)

    def fc_init(self, shape):
        values = np.random.normal(loc=0, scale=1e-1, size=shape)
        return K.variable(values)

    def my_conv(self, filter_size, k_size, inp):
        return Conv2D(filter_size,
                      kernel_size=k_size,
                      activation='relu',
                      kernel_initializer=self.cw_init,
                      kernel_regularizer=l2(2e-4),
                      bias_initializer=self.cb_init)(inp)

    def my_dense(self, size, inp):
        return Dense(size,
                     activation="sigmoid",
                     kernel_regularizer=l2(1e-3),
                     kernel_initializer=self.fc_init,
                     bias_initializer=self.fc_init)(inp)

    def build_base_model(self):
        inp = Input((105, 105, 1))
        x = self.my_conv(64, 10, inp)
        x = MaxPooling2D()(x)
        x = self.my_conv(128, 7, x)
        x = MaxPooling2D()(x)
        x = self.my_conv(128, 4, x)
        x = MaxPooling2D()(x)
        x = self.my_conv(256, 4, x)
        x = Flatten()(x)
        x = self.my_dense(4096, x)
        return Model(inp, x)
