import os
import numpy as np
from utils import get_language_names, read_data, get_batch, test_oneshot
from model import SiameseNet
from keras.optimizers import Adam

dir_path = os.path.dirname(os.path.realpath(__file__))
train_path = os.path.join(dir_path, "data/images_background")
test_path = os.path.join(dir_path, "data/images_evaluation")

train_alphabets, test_alphabets = get_language_names()

train_datas = read_data(train_path, 'train')
test_datas = read_data(test_path, 'test')

model = SiameseNet()
model.siamese_net.compile(
    loss="binary_crossentropy",
    optimizer=Adam(lr=3e-5)
)

evaluate_term = 7000
loss_term = 300
batch_size = 32
N_way = 20
n_val = 550
best = 76.0

for i in range(1500000):
    x, y = get_batch(train_datas, batch_size)
    loss = model.siamese_net.train_on_batch(x, y)
    if i % evaluate_term == 0 and i != 0:
        val_acc = test_oneshot(model.siamese_net, test_datas, N_way, n_val)
        if val_acc >= best:
            print("saving")
            model.siamese_net.save_weights('./weights/model_weight.h5')
            best = val_acc

    if i % loss_term == 0:
        print("iteration {}, training loss: {:.2f},".format(i, loss))
